<?php
      $products = array (
        array("name" => "Donut Bubblegum", "price" => 4.99, "description" => "Glazed, chewy goodness that lasts all day. 30 pieces"),
        array("name" => "Water Bubblegum", "price" => 2.99, "description" => "The most refreshing, tasteless bubblegum you've ever had. 30 pieces"),
        array("name" => "Coffee Bubblegum", "price" => 1.99, "description" => "Have your java without drinking a drop. 30 pieces"),
        array("name" => "Beef Jerky Bubblegum", "price" => 1.95, "description" => "Tired of picking jerky out of your teeth? Now you get the flavor without the floss! 30 pieces"),
        array("name" => "Dandelion Bubblegum", "price" => 2.49, "description" => "Ever wanted to be a herbivore? Now you can! 30 pieces"),
      );
    ?>